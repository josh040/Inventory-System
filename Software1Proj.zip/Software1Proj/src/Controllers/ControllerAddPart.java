
package Controllers;
import java.io.IOException;
import java.net.URL;
import java.util.Random;
import java.util.ResourceBundle;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import Model.InHouse;
import Model.Inventory;
import Model.OutSourced;
import Model.Part;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;

public class ControllerAddPart implements Initializable {

    Inventory inventory;
    @FXML
    TextField price;
    @FXML
    TextField maximum;
    @FXML
    TextField business;
    @FXML
    Label businessTitle;
    @FXML
    TextField minimum;
    @FXML
     RadioButton RadioinHouse;
    @FXML
     RadioButton RadiooutSourced;
    @FXML
     TextField id;
    @FXML
     TextField name;
    @FXML
     TextField number;


    public ControllerAddPart(Inventory inventory) {
        this.inventory = inventory;
    }
     //Initializes the class
    public void initialize(URL uniformresourcelocater, ResourceBundle resourceBundle) {
        genpID();
        fieldsReset();
    }
    //generates part id
    void genpID() {
        boolean b;
        Random randNum = new Random();
        Integer n = randNum.nextInt(100);

        if (inventory.sizePartList() == 0) {
            id.setText(n.toString());
        }
        if (inventory.sizePartList() == 100) {
            MessageAlert.Parterr(4, null);
        } else {
            b = IfTakenverify(n);

            if (b == false) {
                id.setText(n.toString());
            } else {
                genpID();
            }
        }
    }
    //verifies if taken
    boolean IfTakenverify(Integer n) {
        Part b = inventory.PartLookUp(n);
        return b != null;
    }
//Field reset
     void fieldsReset() {
         price.setText("Part Price");
         minimum.setText("Minimum");
         maximum.setText("Maximum");
         business.setText("Tool ID");
         businessTitle.setText("Tool ID");
         RadioinHouse.setSelected(true);
        name.setText("Part Name");
        number.setText("Inventory number");
    }
    @FXML
    void OutSourcedSelect(MouseEvent mouseEvent) {
        businessTitle.setText("business Name");
        business.setText("business Name");
    }

    @FXML
    void Disableid(MouseEvent mouseEvent) {
    }

    @FXML
     void TextFieldclear(MouseEvent mouseEvent) {
        Object mouseEventSource = mouseEvent.getSource();
        TextField mouseEventSource1  = (TextField) mouseEventSource;
        mouseEventSource1.setText("");
    }

    @FXML
     void InHousepick(MouseEvent mouseEvent) {
        businessTitle.setText("Tool ID");
        business.setText("Tool ID");
    }



    @FXML
     void AddPartCancel(MouseEvent mouseEvent) {
        boolean c = MessageAlert.c();
        if (c) {
            Screenmain(mouseEvent);
        }
    }

    @FXML
     void AddPartsave(MouseEvent mouseEvent) {
        FieldsStylereset();
        boolean e = false;
        TextField[] textFields = {number, price, minimum, maximum};
        if (RadioinHouse.isSelected() || RadiooutSourced.isSelected()) {
            for (TextField textField : textFields) {
                boolean ValueCheck = ValueCheck(textField);
                if (ValueCheck) {
                    e = true;
                    break;
                }
                boolean typeCheck = typeCheck(textField);
                if (typeCheck) {
                    e = true;
                    break;
                }
            }
            if (Integer.parseInt(number.getText().trim()) < Integer.parseInt(minimum.getText().trim())) {
                MessageAlert.Parterr(7, number);
                return;
            }
            if (Integer.parseInt(number.getText().trim()) > Integer.parseInt(maximum.getText().trim())) {
                MessageAlert.Parterr(8, number);
                return;
            }
            if (name.getText().trim().isEmpty() || name.getText().trim().toLowerCase().equals("p name")) {
                MessageAlert.Parterr(5, name);
                return;
            }
            if (Integer.parseInt(minimum.getText().trim()) > Integer.parseInt(maximum.getText().trim())) {
                MessageAlert.Parterr(9, minimum);
                return;
            }
            if (e) {
                return;
            } else if (business.getText().trim().isEmpty() || business.getText().trim().toLowerCase().equals("business name")) {
                MessageAlert.Parterr(4, business);
                return;

            } else if (RadioinHouse.isSelected() && !business.getText().trim().matches("[0-9]*")) {
                MessageAlert.Parterr(1, business);
                return;
            } else if (RadioinHouse.isSelected()) {
                addInHouse();

            } else if (RadiooutSourced.isSelected()) {
                addOutSourced();

            }

        } else {
            MessageAlert.Parterr(3, null);
            return;

        }
        Screenmain(mouseEvent);
    }

    void addOutSourced() {
        inventory.PartAdd(new OutSourced(Integer.parseInt(id.getText().trim()), name.getText().trim(),
                Double.parseDouble(price.getText().trim()), Integer.parseInt(number.getText().trim()),
                Integer.parseInt(minimum.getText().trim()), Integer.parseInt(maximum.getText().trim()), business.getText().trim()));

    }
     void addInHouse() {
        inventory.PartAdd(new InHouse(Integer.parseInt(id.getText().trim()), name.getText().trim(),
                Double.parseDouble(price.getText().trim()), Integer.parseInt(number.getText().trim()),
                Integer.parseInt(minimum.getText().trim()), Integer.parseInt(maximum.getText().trim()), (Integer.parseInt(business.getText().trim()))));

    }
    void Screenmain(Event mouseEvent) {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/Views/ScreenMain.fxml"));
            ControllerMainScreen controllerMainScreen = new ControllerMainScreen(inventory);

            fxmlLoader.setController(controllerMainScreen);
            Parent load = fxmlLoader.load();
            Scene scene = new Scene(load);
            Stage w = (Stage) ((Node) mouseEvent.getSource()).getScene().getWindow();
            w.setScene(scene);
            w.setResizable(false);
            w.show();
        } catch (IOException e) {

        }
    }
     void FieldsStylereset() {
         minimum.setStyle("-fx-border-color: black");
         maximum.setStyle("-fx-border-color: black");
         business.setStyle("-fx-border-color: black");
        name.setStyle("-fx-border-color: black");
        number.setStyle("-fx-border-color: black");
        price.setStyle("-fx-border-color: black");
    }
    boolean typeCheck(TextField TextField) {
        if (TextField != price & !TextField.getText().trim().matches("[0-9]*")) {
            MessageAlert.Parterr(4, TextField);
            return true;
        }
        if (TextField == price & !TextField.getText().trim().matches("\\d+(\\.\\d+)?")) {
            MessageAlert.Parterr(4, TextField);
            return true;
        }

        return false;
    }
     boolean ValueCheck(TextField TextField) {
        boolean err = false;
        try {
            if (TextField == price && Double.parseDouble(TextField.getText().trim()) < 0) {
                MessageAlert.Parterr(6, TextField);
                err = true;
            }
            if (TextField.getText().trim().isEmpty() | TextField.getText().trim() == null) {
                MessageAlert.Parterr(2, TextField);
                return true;
            }

        } catch (Exception e) {
            err = true;
            MessageAlert.Parterr(4, TextField);
            System.out.println(e);

        }
        return err;
    }



}
