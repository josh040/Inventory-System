
package Controllers;
import java.io.IOException;
import java.net.URL;
import java.util.Random;
import java.util.ResourceBundle;
import Model.Inventory;
import Model.Part;
import Model.Product;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableCell;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.stage.Stage;

public class ControllerAddProduct implements Initializable {

    Inventory inventory;
    @FXML
    TableView<Part> FindTablePart;
    @FXML
    TableView<Part> partTableView;
    ObservableList<Part> Inventoryparts = FXCollections.observableArrayList();

    ObservableList<Part> partObservableList = FXCollections.observableArrayList();
    @FXML
     TextField id;
    @FXML
     TextField name;
    @FXML
     TextField price;
    @FXML
     TextField number;
    @FXML
     TextField minimum;
    @FXML
     TextField maximum;
    @FXML
     TextField find;


    public ControllerAddProduct(Inventory inventory) {
        this.inventory = inventory;
    }

   //initializes main screen class
    public void initialize(URL uniformresourcelocater, ResourceBundle reasourceBundle) {
        genProductID();
        popfindTable();
    }
    boolean genNum(Integer n) {
        Part b = inventory.PartLookUp(n);
        return b != null;
    }


    void popfindTable() {
        Inventoryparts.setAll(inventory.getPartsAll());

        TableColumn<Part, Double> Colcost = priceFormat();
        FindTablePart.getColumns().addAll(Colcost);

        FindTablePart.setItems(Inventoryparts);
        FindTablePart.refresh();
    }
     void genProductID() {
        boolean b;
        Random randNum = new Random();
        Integer n = randNum.nextInt(100);


        if (inventory.productListSize() == 0) {
            id.setText(n.toString());

        }
        if (inventory.productListSize() == 100) {
            MessageAlert.errProduct(4, null);
        } else {
            b = genNum(n);

            if (b == false) {
                id.setText(n.toString());
            } else {
                genProductID();
            }
        }

        id.setText(n.toString());
    }

    @FXML
    void PartAdd(MouseEvent mouseEvent) {
        Part PartAdd = FindTablePart.getSelectionModel().getSelectedItem();
        boolean Itemrepeated = false;

        if (PartAdd != null) {
            int id = PartAdd.getId();
            for (int i = 0; i < partObservableList.size(); i++) {
                if (partObservableList.get(i).getId() == id) {
                    MessageAlert.errProduct(3, null);
                    Itemrepeated = true;
                }
            }

            if (!Itemrepeated) {
                partObservableList.add(PartAdd);

            }

            TableColumn<Part, Double> Colcost = priceFormat();
            partTableView.getColumns().addAll(Colcost);

            partTableView.setItems(partObservableList);
        }
    }

    @FXML
    void Partd(MouseEvent mouseEvent
    ) {
        Part removePart = partTableView.getSelectionModel().getSelectedItem();
        boolean d = false;
        if (removePart != null) {
            boolean r = MessageAlert.cWindow(removePart.getName());
            if (r) {
                partObservableList.remove(removePart);
                partTableView.refresh();
            }
        } else {
            return;
        }
        if (d) {
            MessageAlert.WindowInfo(2, removePart.getName());
        } else {
            MessageAlert.WindowInfo(3, "");
        }

    }
    @FXML
    void findForPart(MouseEvent mouseEvent) {
        if (!find.getText().trim().isEmpty()) {
            Inventoryparts.clear();
            FindTablePart.setItems(inventory.PartLookUp(find.getText().trim()));
            FindTablePart.refresh();
        }
    }




    @FXML
    void AddProductCancel(MouseEvent mouseEvent
    ) {
        boolean c = MessageAlert.c();
        if (c) {
            Screenmain(mouseEvent);
        }
    }

    @FXML
     void TextFieldclear(MouseEvent mouseEvent) {
        Object o = mouseEvent.getSource();
        TextField TextField = (TextField) o;
        TextField.setText("");
    }



    @FXML
     void AddProductSave(MouseEvent mouseEvent
    ) {
        styleresetfields();
        boolean e = false;
        TextField[] fieldCount = {number, price, minimum, maximum};
        double CostMin = 0;
        for (int i = 0; i < partObservableList.size(); i++) {
            CostMin += partObservableList.get(i).getPrice();
        }
        if (name.getText().trim().isEmpty() || name.getText().trim().toLowerCase().equals("p name")) {
            MessageAlert.errProduct(4, name);
            return;
        }
        for (TextField TextField : fieldCount) {
            boolean valueError = ValueCheck(TextField);
            if (valueError) {
                e = true;
                break;
            }
            boolean typeCheck = typeCheck(TextField);
            if (typeCheck) {
                e = true;
                break;
            }
        }
        if (Integer.parseInt(number.getText().trim()) > Integer.parseInt(maximum.getText().trim())) {
            MessageAlert.errProduct(10, number);
            return;
        }
        if (Double.parseDouble(price.getText().trim()) < CostMin) {
            MessageAlert.errProduct(7, price);
            return;
        }
        if (partObservableList.isEmpty()) {
            MessageAlert.errProduct(8, null);
            return;
        }
        if (Integer.parseInt(minimum.getText().trim()) > Integer.parseInt(maximum.getText().trim())) {
            MessageAlert.errProduct(1, minimum);
            return;
        }
        if (Integer.parseInt(number.getText().trim()) < Integer.parseInt(minimum.getText().trim())) {
            MessageAlert.errProduct(9, number);
            return;
        }


        productSave();
        Screenmain(mouseEvent);

    }

     void ErrorField(TextField TextField) {
        if (TextField != null) {
            TextField.setStyle("-fx-border-color: orange");
        }
    }
    void styleresetfields() {
        price.setStyle("-fx-border-color: black");
        minimum.setStyle("-fx-border-color: black");
        maximum.setStyle("-fx-border-color: black");
        name.setStyle("-fx-border-color: black");
        number.setStyle("-fx-border-color: black");
    }

    @FXML
    void FieldClear(MouseEvent mouseEvent) {
        find.setText("");
        if (!Inventoryparts.isEmpty()) {
            FindTablePart.setItems(Inventoryparts);
        }

    }
     void productSave() {
        Product prod = new Product(Integer.parseInt(id.getText().trim()), name.getText().trim(), Double.parseDouble(price.getText().trim()),
                Integer.parseInt(number.getText().trim()), Integer.parseInt(minimum.getText().trim()), Integer.parseInt(maximum.getText().trim()));
        for (int i = 0; i < partObservableList.size(); i++) {
            prod.addAssociatedPart(partObservableList.get(i));
        }

        inventory.ProductAdd(prod);

    }

    boolean ValueCheck(TextField TextField) {
        boolean err = false;
        try {
            if (TextField == price && Double.parseDouble(TextField.getText().trim()) < 0) {
                MessageAlert.errProduct(6, TextField);
                err = true;
            }
            if (TextField.getText().trim().isEmpty() || TextField.getText().trim() == null) {
                MessageAlert.errProduct(2, TextField);
                return true;
            }

        } catch (NumberFormatException e) {
            err = true;
            MessageAlert.errProduct(4, TextField);
            System.out.println(e);

        }
        return err;
    }

    boolean typeCheck(TextField TextField) {
        if (TextField != price & !TextField.getText().trim().matches("[0-9]*")) {
            MessageAlert.errProduct(4, TextField);
            return true;
        }
        if (TextField == price & !TextField.getText().trim().matches("\\d+(\\.\\d+)?")) {
            MessageAlert.errProduct(4, TextField);
            return true;
        }

        return false;

    }

     void Screenmain(Event mouseEvent) {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/Views/ScreenMain.fxml"));
            ControllerMainScreen controllerMainScreen = new ControllerMainScreen(inventory);

            fxmlLoader.setController(controllerMainScreen);
            Parent load = fxmlLoader.load();
            Scene scene = new Scene(load);
            Stage w = (Stage) ((Node) mouseEvent.getSource()).getScene().getWindow();
            w.setScene(scene);
            w.setResizable(false);
            w.show();
        } catch (IOException e) {

        }
    }



     <T> TableColumn<T, Double> priceFormat() {
        TableColumn<T, Double> Colcost = new TableColumn<>("Price");
        Colcost.setCellValueFactory(new PropertyValueFactory<>("Price"));
        Colcost.setCellFactory((TableColumn<T, Double> column) -> {
            return new TableCell<T, Double>() {
                
                protected void updateItem(Double i, boolean e) {
                    if (!e) {
                        setText("$" + String.format("%1.2f", i));
                    } else {
                        setText("");
                    }
                }
            };
        });
        return Colcost;
    }

}
