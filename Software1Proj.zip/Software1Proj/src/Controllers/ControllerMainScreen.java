
package Controllers;
import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
import Model.Inventory;
import Model.Part;
import Model.Product;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;




public class ControllerMainScreen implements Initializable {
    @FXML
    TableView<Product> TableProducts;
    ObservableList<Part> InventoryPart = FXCollections.observableArrayList();
    ObservableList<Product> InventoryProduct = FXCollections.observableArrayList();
    ObservableList<Product> InventoryProductfind = FXCollections.observableArrayList();
    Inventory inventory;
//part find text field
    @FXML
     TextField partfindBox;
//product find text field
    @FXML
     TextField productfindBox;
//displays table with parts
    @FXML
     TableView<Part> TableParts;
//displays table with products


    public ControllerMainScreen(Inventory inventory) {
        this.inventory = inventory;
    }

  //initializes main screen class
    public void initialize(URL uniformresourcelocater, ResourceBundle reasourceBundle) {
        genPartsTable();
        genTableProducts();
    }
    //generates products table
    void genTableProducts() {
        InventoryProduct.setAll(inventory.getproductsAll());

        TableColumn<Product, Double> Colcost = priceFormat();
        TableProducts.getColumns().addAll(Colcost);

        TableProducts.setItems(InventoryProduct);
        TableProducts.refresh();
    }
    //generates parts table
     void genPartsTable() {
        InventoryPart.setAll(inventory.getPartsAll());

        TableColumn<Part, Double> Colcost = priceFormat();
        TableParts.getColumns().addAll(Colcost);

        TableParts.setItems(InventoryPart);
        TableParts.refresh();
    }
//look up part; looks up by name which is allowed because it says look up by ID or name
    @FXML
    void findForPart(MouseEvent mouseEvent) {
        if (!partfindBox.getText().trim().isEmpty()) {
            TableParts.setItems(inventory.PartLookUp(partfindBox.getText().trim()));
            TableParts.refresh();
        }
    }

    //looks for product; looks up by name which is allowed because it says look up by ID or name
    @FXML
    void findForProduct(MouseEvent mouseEvent
    ) {
        if (!productfindBox.getText().trim().isEmpty()) {
            InventoryProductfind.clear();
            for (Product p : inventory.getproductsAll()) {
                if (p.getName().contains(productfindBox.getText().trim())) {
                    InventoryProductfind.add(p);
                }
            }
            TableProducts.setItems(InventoryProductfind);
            TableProducts.refresh();
        }
    }

    @FXML
     void ProgramExit(ActionEvent mouseEvent
    ) {
        Platform.exit();
    }

    @FXML
     void ProgramExitButton(MouseEvent mouseEvent
    ) {
        Platform.exit();
    }



    //goes to the add part screen
    @FXML
    void PartAdd(MouseEvent mouseEvent
    ) {

        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/Views/PartAdd.fxml"));
            ControllerAddPart controllerMainScreen = new ControllerAddPart(inventory);

            fxmlLoader.setController(controllerMainScreen);
            Parent load = fxmlLoader.load();
            Scene scene = new Scene(load);
            Stage w = (Stage) ((Node) mouseEvent.getSource()).getScene().getWindow();
            w.setScene(scene);
            w.setResizable(false);
            w.show();
        } catch (IOException e) {

        }
    }

    //goes to the modify part screen
    @FXML
    void PartModify(MouseEvent mouseEvent
    ) {
        try {
            Part picked = TableParts.getSelectionModel().getSelectedItem();
            if (InventoryPart.isEmpty()) {
                errWindow(1);
                return;
            }
            if (!InventoryPart.isEmpty() && picked == null) {
                errWindow(2);
                return;
            } else {
                FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/Views/PartModify.fxml"));
                ControllerModifyPart controllerMainScreen = new ControllerModifyPart(inventory, picked);

                fxmlLoader.setController(controllerMainScreen);
                Parent load = fxmlLoader.load();
                Scene scene = new Scene(load);
                Stage w = (Stage) ((Node) mouseEvent.getSource()).getScene().getWindow();
                w.setScene(scene);
                w.setResizable(false);
                w.show();

            }
        } catch (IOException e) {

        }
    }
   //clears the textfields
    @FXML
    void TextClear(MouseEvent mouseEvent
    ) {
        Object o = mouseEvent.getSource();
        TextField TextField = (TextField) o;
        TextField.setText("");
        if (partfindBox == TextField) {
            if (InventoryPart.size() != 0) {
                TableParts.setItems(InventoryPart);
            }
        }
        if (productfindBox == TextField) {
            if (InventoryProduct.size() != 0) {
                TableProducts.setItems(InventoryProduct);
            }
        }
    }



    @FXML
     void Partd(MouseEvent mouseEvent
    ) {
        Part removePart = TableParts.getSelectionModel().getSelectedItem();
        if (InventoryPart.isEmpty()) {
            errWindow(1);
            return;
        }
        if (!InventoryPart.isEmpty() && removePart == null) {
            errWindow(2);
            return;
        } else {
            boolean c = cWindow(removePart.getName());
            if (!c) {
                return;
            }
            inventory.Partd(removePart);
            InventoryPart.remove(removePart);
            TableParts.refresh();

        }
    }
    //goes to modify product screen
    @FXML
    void productModify(MouseEvent mouseEvent
    ) {
        try {
            Product SelectedProducts = TableProducts.getSelectionModel().getSelectedItem();
            if (InventoryProduct.isEmpty()) {
                errWindow(1);
                return;
            }
            if (!InventoryProduct.isEmpty() && SelectedProducts == null) {
                errWindow(2);
                return;

            } else {
                FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/Views/ProductModify.fxml"));
                ControllerModifyProduct controllerMainScreen = new ControllerModifyProduct(inventory, SelectedProducts);

                fxmlLoader.setController(controllerMainScreen);
                Parent load = fxmlLoader.load();
                Scene scene = new Scene(load);
                Stage w = (Stage) ((Node) mouseEvent.getSource()).getScene().getWindow();
                w.setScene(scene);
                w.setResizable(false);
                w.show();
            }
        } catch (IOException e) {

        }
    }
    @FXML
     void productd(MouseEvent mouseEvent
    ) {
        boolean d = false;
        Product ProductRemove = TableProducts.getSelectionModel().getSelectedItem();
        if (!InventoryProduct.isEmpty() && ProductRemove == null) {
            errWindow(2);
            return;
        }
        if (InventoryProduct.isEmpty()) {
            errWindow(1);
            return;
        }

        if (ProductRemove.getPartsListSize() == 0) {
            boolean c = cd(ProductRemove.getName());
            if (!c) {
                return;
            }
        } else {
            WindowInfo(ProductRemove.getName());
            return;
        }
        inventory.ProductRemove(ProductRemove.getProductID());
        InventoryProduct.remove(ProductRemove);
        TableProducts.setItems(InventoryProduct);
        TableProducts.refresh();
    }


    boolean cWindow(String name) {
        Alert alert = new Alert(AlertType.CONFIRMATION);
        alert.setHeaderText("Do you want to delete " + name);
        alert.setContentText("To cancel click ok");
        alert.setTitle("Delete Part");


        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == ButtonType.OK) {
            return true;
        } else {
            return false;
        }
    }

    boolean cd(String name) {
        Alert alert = new Alert(AlertType.CONFIRMATION);
        alert.setHeaderText("Do you want to delete: " + name);
        alert.setContentText("To cancel click ok");
        alert.setTitle("Product Delete");


        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == ButtonType.OK) {
            return true;
        } else {
            return false;
        }
    }
    @FXML
     void ProductAdd(MouseEvent mouseEvent
    ) {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/Views/ProductAdd.fxml"));
            ControllerAddProduct controllerMainScreen = new ControllerAddProduct(inventory);

            fxmlLoader.setController(controllerMainScreen);
            Parent load = fxmlLoader.load();
            Scene scene = new Scene(load);
            Stage w = (Stage) ((Node) mouseEvent.getSource()).getScene().getWindow();
            w.setScene(scene);
            w.setResizable(false);
            w.show();

        } catch (IOException e) {

        }
    }

     void errWindow(int c) {
         if (c == 2) {
             Alert alert = new Alert(AlertType.ERROR);
             alert.setHeaderText("Incorrect Selection");
             alert.setContentText("You haven't picked an item");
             alert.setTitle("Error");

             alert.showAndWait();
         }
        if (c == 1) {
            Alert alert = new Alert(AlertType.ERROR);
            alert.setHeaderText("Inventory error");
            alert.setContentText("You haven't picked anything");
            alert.setTitle("Error");

            alert.showAndWait();
        }


    }

    <T> TableColumn<T, Double> priceFormat() {
        TableColumn<T, Double> Colcost = new TableColumn<>("Price");
        Colcost.setCellValueFactory(new PropertyValueFactory<>("Price"));
        Colcost.setCellFactory((TableColumn<T, Double> column) -> {
            return new TableCell<T, Double>() {

                protected void updateItem(Double i, boolean e) {
                    if (!e) {
                        setText("$" + String.format("%1.2f", i));
                    } else {
                        setText("");
                    }
                }
            };
        });
        return Colcost;
    }

     void WindowInfo(String name) {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle("Confirmed");
        alert.setHeaderText(null);
        alert.setContentText(name + " The parts assigned to it have not been deleted");
        alert.showAndWait();
    }



}
