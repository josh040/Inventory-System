
package Controllers;
import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
import Model.InHouse;
import Model.Inventory;
import Model.OutSourced;
import Model.Part;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.scene.Node;
import javafx.scene.Parent;

import javafx.stage.Stage;



public class ControllerModifyPart implements Initializable {

    Inventory inventory;
    Part p;
    @FXML
    TextField id;
    @FXML
    TextField name;
    @FXML
    TextField price;
    @FXML
    TextField number;
    @FXML
    TextField minimum;
    @FXML
    TextField maximum;
    @FXML
    TextField business;

    @FXML
     RadioButton RadioinHouse;
    @FXML
     RadioButton RadiooutSourced;
    @FXML
     Label businessTitle;


    public ControllerModifyPart(Inventory inventory, Part p) {
        this.inventory = inventory;
        this.p = p;
    }



  //initializes main screen
    public void initialize(URL uniformresourcelocater, ResourceBundle reasourceBundle) {
        dataSet();
    }

    @FXML
    void InHousepick(MouseEvent mouseEvent
    ) {
        businessTitle.setText("Tool ID");

    }

    @FXML
    void OutSourcedSelect(MouseEvent mouseEvent
    ) {
        businessTitle.setText("business Name");

    }

    @FXML
    void Disableid(MouseEvent mouseEvent
    ) {
    }
     void dataSet() {

        if (p instanceof InHouse) {

            InHouse part1 = (InHouse) p;
            RadioinHouse.setSelected(true);
            businessTitle.setText("Tool ID");
            this.price.setText((Double.toString(part1.getPrice())));
            this.minimum.setText((Integer.toString(part1.getMin())));
            this.maximum.setText((Integer.toString(part1.getMax())));
            this.business.setText((Integer.toString(part1.getmachID())));
            this.name.setText(part1.getName());
            this.id.setText((Integer.toString(part1.getId())));
            this.number.setText((Integer.toString(part1.getStock())));


        }

        if (p instanceof OutSourced) {

            OutSourced part2 = (OutSourced) p;
            RadiooutSourced.setSelected(true);
            businessTitle.setText("business Name");
            this.price.setText((Double.toString(part2.getPrice())));
            this.minimum.setText((Integer.toString(part2.getMin())));
            this.maximum.setText((Integer.toString(part2.getMax())));
            this.business.setText(part2.getbuisnessName());
            this.name.setText(part2.getName());
            this.id.setText((Integer.toString(part2.getId())));
            this.number.setText((Integer.toString(part2.getStock())));

        }
    }
    @FXML
    void ModifyPartSave(MouseEvent mouseEvent
    ) {
        styleresetfields();
        boolean e = false;
        TextField[] fieldCount = {number, price, minimum, maximum};
        if (RadioinHouse.isSelected() || RadiooutSourced.isSelected()) {
            for (int i = 0; i < fieldCount.length; i++) {
                boolean valueError = ValueCheck(fieldCount[i]);
                if (valueError) {
                    e = true;
                    break;
                }
                boolean typeError = typeCheck(fieldCount[i]);
                if (typeError) {
                    e = true;
                    break;
                }
            }
            if (e) {
                return;
            } else if (RadiooutSourced.isSelected() && business.getText().trim().isEmpty()) {
                MessageAlert.Parterr(2, business);
                return;
            } else if (RadioinHouse.isSelected() && !business.getText().matches("[0-9]*")) {
                MessageAlert.Parterr(1, business);
                return;
            } else if (RadiooutSourced.isSelected() & p instanceof OutSourced) {
                updateitemoutsourced();
            } else if (RadiooutSourced.isSelected() & p instanceof InHouse) {
                updateitemoutsourced();
            }
        } else if (RadioinHouse.isSelected() & p instanceof InHouse) {
            uupdateiteminhouse();

        } else if (RadioinHouse.isSelected() & p instanceof OutSourced) {
            uupdateiteminhouse();

            if (Integer.parseInt(number.getText().trim()) < Integer.parseInt(minimum.getText().trim())) {
                MessageAlert.Parterr(7, number);
                return;
            }
            if (Integer.parseInt(number.getText().trim()) > Integer.parseInt(maximum.getText().trim())) {
                MessageAlert.Parterr(8, number);
                return;
            }
            if (name.getText().trim().isEmpty() || name.getText().trim().toLowerCase().equals("p name")) {
                MessageAlert.Parterr(5, name);
                return;
            }
            if (Integer.parseInt(minimum.getText().trim()) > Integer.parseInt(maximum.getText().trim())) {
                MessageAlert.Parterr(9, minimum);
                return;
            }




        } else {
            MessageAlert.Parterr(3, null);
            return;

        }
        Screenmain(mouseEvent);
    }

    void uupdateiteminhouse() {
        inventory.PartUpdate(new InHouse(Integer.parseInt(id.getText().trim()), name.getText().trim(),
                Double.parseDouble(price.getText().trim()), Integer.parseInt(number.getText().trim()),
                Integer.parseInt(minimum.getText().trim()), Integer.parseInt(maximum.getText().trim()), Integer.parseInt(business.getText().trim())));
    }
    @FXML
     void TextFieldclear(MouseEvent mouseEvent
    ) {
        Object o = mouseEvent.getSource();
        TextField TextField = (TextField) o;
        TextField.setText("");
    }


    @FXML
     void ModifyPartCancel(MouseEvent mouseEvent
    ) {
        boolean c = c();
        if (c) {
            Screenmain(mouseEvent);
        } else {
            return;
        }
    }



     void updateitemoutsourced() {
        inventory.PartUpdate(new OutSourced(Integer.parseInt(id.getText().trim()), name.getText().trim(),
                Double.parseDouble(price.getText().trim()), Integer.parseInt(number.getText().trim()),
                Integer.parseInt(minimum.getText().trim()), Integer.parseInt(maximum.getText().trim()), business.getText().trim()));
    }

     void styleresetfields() {
         minimum.setStyle("-fx-border-color: black");
         maximum.setStyle("-fx-border-color: black");
         business.setStyle("-fx-border-color: black");
        name.setStyle("-fx-border-color: black");
        number.setStyle("-fx-border-color: black");
        price.setStyle("-fx-border-color: black");


    }



     boolean typeCheck(TextField TextField) {
         if (TextField != price & !TextField.getText().trim().matches("[0-9]*")) {
             MessageAlert.Parterr(4, TextField);
             return true;
         }
        if (TextField == price & !TextField.getText().trim().matches("\\d+(\\.\\d+)?")) {
            MessageAlert.Parterr(4, TextField);
            return true;
        }

        return false;

    }

     boolean c() {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
         alert.setHeaderText("Confirm Cancel?");
         alert.setContentText("To cancel click ok");
        alert.setTitle("c");


        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == ButtonType.OK) {
            return true;
        } else {
            return false;
        }
    }
    void Screenmain(MouseEvent mouseEvent) {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/Views/ScreenMain.fxml"));
            ControllerMainScreen controllerMainScreen = new ControllerMainScreen(inventory);

            fxmlLoader.setController(controllerMainScreen);
            Parent load = fxmlLoader.load();
            Scene scene = new Scene(load);
            Stage w = (Stage) ((Node) mouseEvent.getSource()).getScene().getWindow();
            w.setScene(scene);
            w.setResizable(false);
            w.show();
        } catch (IOException e) {

        }
    }

    boolean ValueCheck(TextField TextField) {
        boolean err = false;
        try {
            if (TextField == price && Double.parseDouble(TextField.getText().trim()) <= 0.0) {
                MessageAlert.Parterr(6, TextField);
                err = true;
            }
            if (TextField.getText().trim().isEmpty() || TextField.getText().trim() == null) {
                MessageAlert.Parterr(2, TextField);
                return true;
            }

        } catch (Exception e) {
            err = true;
            MessageAlert.Parterr(4, TextField);
            System.out.println(e);

        }
        return err;
    }
}
