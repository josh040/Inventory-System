
package Controllers;
import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
import Model.Inventory;
import Model.Part;
import Model.Product;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;




public class ControllerModifyProduct implements Initializable {

    Inventory inventory;
    Product prod;
    @FXML
    TextField minimum;
    @FXML
    TextField maximum;
    @FXML
    TableView<Part> partTableView;
    @FXML
    TableView<Part> FindTablePart;
    @FXML
    TextField find;
    ObservableList<Part> Inventoryparts = FXCollections.observableArrayList();
    ObservableList<Part> partsInventoryfind = FXCollections.observableArrayList();
    ObservableList<Part> partObservableList = FXCollections.observableArrayList();
    @FXML
     TextField id;
    @FXML
     TextField name;
    @FXML
     TextField price;
    @FXML
     TextField number;


    public ControllerModifyProduct(Inventory inventory, Product prod) {
        this.inventory = inventory;
        this.prod = prod;
    }

    //initalizes main screen class
    public void initialize(URL uniformresourcelocater, ResourceBundle reasourceBundle) {
        popfindTable();
        dataSet();
    }
    @FXML
    void modifyProductfind(MouseEvent mouseEvent) {
        if (find.getText() != null && find.getText().trim().length() != 0) {
            partsInventoryfind.clear();
            for (Part p : inventory.getPartsAll()) {
                if (p.getName().contains(find.getText().trim())) {
                    partsInventoryfind.add(p);
                }
            }
            FindTablePart.setItems(partsInventoryfind);
        }
    }

    @FXML
    void Partd(MouseEvent mouseEvent) {
        Part removePart = partTableView.getSelectionModel().getSelectedItem();
        boolean d = false;
        if (removePart != null) {
            boolean remove = cWindow(removePart.getName());
            if (remove) {
                d = prod.removeAssociatedPart(removePart.getId());
                partObservableList.remove(removePart);
                partTableView.refresh();
            }
        } else {
            return;
        }
        if (d) {
            MessageAlert.WindowInfo(2, removePart.getName());
        } else {
            MessageAlert.WindowInfo(3, "");
        }

    }
     void popfindTable() {
        Inventoryparts.setAll(inventory.getPartsAll());

         FindTablePart.setItems(Inventoryparts);
         FindTablePart.refresh();
        TableColumn<Part, Double> Colcost = priceFormat();
        FindTablePart.getColumns().addAll(Colcost);

    }

    @FXML
    void TextFieldclear(MouseEvent mouseEvent) {
        Object o = mouseEvent.getSource();
        TextField TextField = (TextField) o;
        TextField.setText("");
        if (TextField == find) {
            FindTablePart.setItems(Inventoryparts);
        }
    }



    @FXML
     void PartAdd(MouseEvent mouseEvent) {
        Part PartAdd = FindTablePart.getSelectionModel().getSelectedItem();
        boolean repeatedItem = false;

        if (PartAdd == null) {
            return;
        } else {
            int id = PartAdd.getId();
            for (int i = 0; i < partObservableList.size(); i++) {
                if (partObservableList.get(i).getId() == id) {
                    MessageAlert.errProduct(3, null);
                    repeatedItem = true;
                }
            }

            if (!repeatedItem) {
                partObservableList.add(PartAdd);
            }
            partTableView.setItems(partObservableList);
        }
    }



     void productSave() {
        Product prod = new Product(Integer.parseInt(id.getText().trim()), name.getText().trim(), Double.parseDouble(price.getText().trim()),
                Integer.parseInt(number.getText().trim()), Integer.parseInt(minimum.getText().trim()), Integer.parseInt(maximum.getText().trim()));
        for (int i = 0; i < partObservableList.size(); i++) {
            prod.addAssociatedPart(partObservableList.get(i));
        }

        inventory.ProductUpdate(prod);

    }

     void dataSet() {
        for (int i = 0; i < 1000; i++) {
            Part p = prod.lookupAssociatedPart(i);
            if (p != null) {
                partObservableList.add(p);
            }
        }


         this.price.setText((Double.toString(prod.getPrice())));
         this.minimum.setText((Integer.toString(prod.getMin())));
         this.maximum.setText((Integer.toString(prod.getMax())));
        this.name.setText(prod.getName());
        this.id.setText((Integer.toString(prod.getProductID())));
        this.number.setText((Integer.toString(prod.getInStock())));
         TableColumn<Part, Double> Colcost = priceFormat();
         partTableView.getColumns().addAll(Colcost);

         partTableView.setItems(partObservableList);

    }
    @FXML
    void ModifyCancel(MouseEvent mouseEvent) {
        boolean c = MessageAlert.c();
        if (c) {
            Screenmain(mouseEvent);
        } else {
            return;
        }
    }

    @FXML
    void productSave(MouseEvent mouseEvent) {
        styleresetfields();
        boolean e = false;
        TextField[] fieldCount = {number, price, minimum, maximum};
        double CostMin = 0;
        for (int i = 0; i < partObservableList.size(); i++) {
            CostMin += partObservableList.get(i).getPrice();
        }
        if (name.getText().trim().isEmpty() || name.getText().trim().toLowerCase().equals("p name")) {
            MessageAlert.errProduct(5, name);
            return;
        }
        for (int i = 0; i < fieldCount.length; i++) {
            boolean valueError = ValueCheck(fieldCount[i]);
            if (valueError) {
                e = true;
                break;
            }
            boolean typeError = typeCheck(fieldCount[i]);
            if (typeError) {
                e = true;
                break;
            }
        }
        if (Integer.parseInt(number.getText().trim()) > Integer.parseInt(maximum.getText().trim())) {
            MessageAlert.errProduct(10, number);
            return;
        }
        if (Double.parseDouble(price.getText().trim()) < CostMin) {
            MessageAlert.errProduct(7, price);
            return;
        }
        if (partObservableList.size() == 0) {
            MessageAlert.errProduct(8, null);
            return;
        }
        if (Integer.parseInt(minimum.getText().trim()) > Integer.parseInt(maximum.getText().trim())) {
            MessageAlert.errProduct(1, minimum);
            return;
        }
        if (Integer.parseInt(number.getText().trim()) < Integer.parseInt(minimum.getText().trim())) {
            MessageAlert.errProduct(9, number);
            return;
        }


        productSave();
        Screenmain(mouseEvent);

    }

     void styleresetfields() {
         price.setStyle("-fx-border-color: black");
         minimum.setStyle("-fx-border-color: black");
         maximum.setStyle("-fx-border-color: black");
        name.setStyle("-fx-border-color: black");
        number.setStyle("-fx-border-color: black");


    }

     boolean cWindow(String name) {
        Alert alert = new Alert(AlertType.CONFIRMATION);
         alert.setHeaderText("Confirm delete of: " + name);
         alert.setContentText("To cancel click ok");
        alert.setTitle("delete part");


        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == ButtonType.OK) {
            return true;
        } else {
            return false;
        }
    }
    boolean typeCheck(TextField TextField) {
        if (TextField != price & !TextField.getText().trim().matches("[0-9]*")) {
            MessageAlert.errProduct(4, TextField);
            return true;
        }
        if (TextField == price & !TextField.getText().trim().matches("\\d+(\\.\\d+)?")) {
            MessageAlert.errProduct(4, TextField);
            return true;
        }

        return false;

    }

    <T> TableColumn<T, Double> priceFormat() {
        TableColumn<T, Double> Colcost = new TableColumn<>("Price");
        Colcost.setCellValueFactory(new PropertyValueFactory<>("Price"));
        Colcost.setCellFactory((TableColumn<T, Double> column) -> {
            return new TableCell<T, Double>() {

                protected void updateItem(Double i, boolean e) {
                    if (!e) {
                        setText("$" + String.format("%1.2f", i));
                    } else {
                        setText("");
                    }
                }
            };
        });
        return Colcost;
    }
     void Screenmain(Event mouseEvent) {
        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/Views/ScreenMain.fxml"));
            ControllerMainScreen controllerMainScreen = new ControllerMainScreen(inventory);

            fxmlLoader.setController(controllerMainScreen);
            Parent load = fxmlLoader.load();
            Scene scene = new Scene(load);
            Stage w = (Stage) ((Node) mouseEvent.getSource()).getScene().getWindow();
            w.setScene(scene);
            w.setResizable(false);
            w.show();
        } catch (IOException e) {

        }
    }

     boolean ValueCheck(TextField TextField) {
        boolean err = false;
        try {
            if (TextField == price && Double.parseDouble(TextField.getText().trim()) < 0) {
                MessageAlert.errProduct(6, TextField);
                err = true;
            }
            if (TextField.getText().trim().isEmpty() || TextField.getText().trim() == null) {
                MessageAlert.errProduct(2, TextField);
                return true;
            }

        } catch (Exception e) {
            err = true;
            MessageAlert.errProduct(4, TextField);
            System.out.println(e);

        }
        return err;
    }



}
