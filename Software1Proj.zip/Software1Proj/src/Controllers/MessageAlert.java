
package Controllers;

import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TextField;

import java.util.Optional;

public class MessageAlert {
    static void ErrorField(TextField TextField) {
        if (TextField != null) {
            TextField.setStyle("-fx-border-color: orange");
        }
    }

    public static boolean cWindow(String name) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("delete part");
        alert.setHeaderText("Confirm delete: " + name);
        alert.setContentText("To confirm click ok");
        Optional<ButtonType> result = alert.showAndWait();
        return result.get() == ButtonType.OK;
    }
    public static void errProduct(int c, TextField TextField) {
        ErrorField(TextField);

        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Cannot add product");
        alert.setHeaderText("Incorrect Product");
        switch (c) {
            default: {
                alert.setContentText("Error unknown");
                break;
            }
            case 1: {
                alert.setContentText("Maximum must be less then minimum");
                break;
            }
            case 2: {
                alert.setContentText("Empty textfield!");
                break;
            }
            case 3: {
                alert.setContentText("Part is associated with product already");
                break;
            }
            case 4: {
                alert.setContentText("Format is incorrect!");
                break;
            }
            case 5: {
                alert.setContentText("Invalid Name!");
                break;
            }
            case 6: {
                alert.setContentText("Negative values are not allowed");
                break;
            }
            case 7: {
                alert.setContentText("The cost of a product can not be lower then it's parts");
                break;
            }
            case 8: {
                alert.setContentText("A product has to have at least one part");
                break;
            }
            case 9: {
                alert.setContentText("Minimum must be less then inventory");
                break;
            }
            case 10: {
                alert.setContentText("Maximum must be greater then inventory");
                break;
            }


        }
        alert.showAndWait();
    }

    public static boolean c() {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("cancel");
        alert.setHeaderText("Confirm Cancel");
        alert.setContentText("To cancel click ok");
        Optional<ButtonType> result = alert.showAndWait();
        return result.get() == ButtonType.OK;
    }

    public static void WindowInfo(int c, String name) {
        if (c != 2) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Confirmed");
            alert.setHeaderText(null);
            alert.setContentText(name + " is deleted");
            alert.showAndWait();
        } else {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Error");
            alert.setHeaderText(null);
            alert.setContentText("Error!");
        }
    }
    public static void Parterr(int c, TextField TextField) {
        ErrorField(TextField);

        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Cannot add part");
        alert.setHeaderText("Cannot add part");
        switch (c) {
            default: {
                alert.setContentText("Error Unknown!");
                break;
            }
            case 1: {
                alert.setContentText("Tool ID must have a number");
                break;
            }
            case 2: {
                alert.setContentText("Empty textfield!");
                break;
            }
            case 3: {
                alert.setContentText("You have to select InHouse/OutSourced");
                break;
            }
            case 4: {
                alert.setContentText("Incorrect format!");
                break;
            }
            case 5: {
                alert.setContentText("Incorrect Name!");
                break;
            }
            case 6: {
                alert.setContentText("Negative/zero values not allowed!!");
                break;
            }
            case 7: {
                alert.setContentText("Inventories must be greater then minimum");
                break;
            }
            case 8: {
                alert.setContentText("Inventories must be less then maximum");
                break;
            }
            case 9: {
                alert.setContentText("Minimum must be less than maximum!");
                break;
            }


        }
        alert.showAndWait();
    }



}
