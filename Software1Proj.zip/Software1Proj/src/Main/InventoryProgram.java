
package Main;

import Controllers.ControllerMainScreen;
import Model.*;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;


public class InventoryProgram extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    
    public void start(Stage w) throws Exception {
        Inventory inventory = new Inventory();
        TestDataAdd(inventory);

        FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/Views/ScreenMain.fxml"));
        ControllerMainScreen controllerMainScreen = new ControllerMainScreen(inventory);
        fxmlLoader.setController(controllerMainScreen);
        Parent load = fxmlLoader.load();
        Scene scene = new Scene(load);
        w.setScene(scene);
        w.setResizable(false);
        w.show();
    }

    void TestDataAdd(Inventory inventory) {
//in house parts
        Part x2 = new InHouse(4, "Part x2", 4.00, 2, 1, 100, 102);
        Part y = new InHouse(3, "Part y", 3.00, 3, 1, 100, 103);
        Part x1 = new InHouse(2, "Part x1", 2.00, 1, 1, 100, 100);
        inventory.PartAdd(new InHouse(1, "Part x3", 1.00, 11, 1, 100, 104));
        inventory.PartAdd(new InHouse(5, "Part x4", 5.00, 4, 1, 100, 101));
        inventory.PartAdd(y);
        inventory.PartAdd(x2);
        inventory.PartAdd(x1);


        //out sourced parts
        Part k = new OutSourced(8, "Part k", 3.00, 5, 1, 100, "Business 3");
        Part i1 = new OutSourced(6, "Part i1", 1.00, 1, 1, 100, "Business 1");
        Part j = new OutSourced(7, "Part j", 2.00, 8, 1, 100, "Business 2");


        inventory.PartAdd(new OutSourced(9, "Part n", 1.00, 1, 1, 100, "Business 4"));
        inventory.PartAdd(new OutSourced(10, "Part i2", 1.00, 1, 1, 100, "Business 5"));
        inventory.PartAdd(j);
        inventory.PartAdd(k);
        inventory.PartAdd(i1);


        //Add productsAll
        inventory.ProductAdd(new Product(400, "Brake Pedal", 18.00, 19, 1, 100));
        Product prod1 = new Product(200, "Motor", 10.00, 10, 1, 100);
        prod1.addAssociatedPart(x1);
        prod1.addAssociatedPart(i1);
        inventory.ProductAdd(prod1);
        Product prod4 = new Product(100, "Tires", 19.00, 10, 1, 100);
        inventory.ProductAdd(prod4);

        Product prod3 = new Product(500, "Wheels", 13.00, 20, 1, 100);
        prod3.addAssociatedPart(y);
        prod3.addAssociatedPart(k);
        inventory.ProductAdd(prod3);
        Product prod2 = new Product(300, "Steering Wheel", 15.00, 19, 1, 100);
        prod2.addAssociatedPart(x2);
        prod2.addAssociatedPart(j);
        inventory.ProductAdd(prod2);




    }

}
