
package Model;


public class InHouse extends Part {

     int machID;
    public int getmachID() {
        return machID;
    }

    public void setmachid(int id) {
        this.machID = id;
    }
    public InHouse(int pID, String name, double price, int numberinstock, int minimum, int maximum, int machID) {
        setmin(minimum);
        setmax(maximum);
        setmachid(machID);
        setid(pID);
        setname(name);
        setprice(price);
        setstock(numberinstock);

    }



}
