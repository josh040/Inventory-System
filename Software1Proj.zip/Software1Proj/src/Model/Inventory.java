
package Model;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class Inventory {
    ObservableList<Part> PartsAll = FXCollections.observableArrayList();
     ObservableList<Product> productsAll = FXCollections.observableArrayList();

    public void ProductUpdate(Product prod) {
        for (int i = 0; i < productsAll.size(); i++) {
            if (productsAll.get(i).getProductID() == prod.getProductID()) {
                productsAll.set(i, prod);
                break;
            }
        }
        return;
    }

    public void PartAdd(Part partToAdd) {
        if (partToAdd != null) {
            PartsAll.add(partToAdd);
        }
    }
    public void ProductAdd(Product productAdd) {
        if (productAdd != null) {
            this.productsAll.add(productAdd);
        }
    }
    public Part PartLookUp(int i1) {
        if (!PartsAll.isEmpty()) {
            for (int i = 0; i < PartsAll.size(); i++) {
                if (PartsAll.get(i).getId() == i1) {
                    return PartsAll.get(i);
                }
            }

        }
        return null;
    }

    public ObservableList<Part> PartLookUp(String s) {
        if (!PartsAll.isEmpty()) {
            ObservableList findPartsList = FXCollections.observableArrayList();
            for (Part p : getPartsAll()) {
                if (p.getName().contains(s)) {
                    findPartsList.add(p);
                }
            }
            return findPartsList;
        }
        return null;
    }
    public Product ProductLookUp(int prodSearch) {
        if (!productsAll.isEmpty()) {
            for (int i = 0; i < productsAll.size(); i++) {
                if (productsAll.get(i).getProductID() == prodSearch) {
                    return productsAll.get(i);
                }
            }
        }
        return null;
    }

    public ObservableList<Part> ProdLookUp(String prodLookUp) {
        return null;
    }

    public boolean ProductRemove(int productRemove) {
        for (int i = 0; i < productsAll.size(); i++) {
            if (productsAll.get(i).getProductID() == productRemove) {
                productsAll.remove(i);
                return true;
            }
        }
        return false;
    }



    public boolean Partd(Part partTod) {
        for (int i = 0; i < PartsAll.size(); i++) {
            if (PartsAll.get(i).getId() == partTod.getId()) {
                PartsAll.remove(i);
                return true;
            }
        }
        return false;
    }



    public void PartUpdate(Part part) {
        for (int i = 0; i < PartsAll.size(); i++) {
            if (PartsAll.get(i).getId() == part.getId()) {
                PartsAll.set(i, part);
                break;
            }
        }
        return;
    }
    public int sizePartList() {
        return PartsAll.size();
    }

    public int productListSize() {
        return productsAll.size();
    }
    public ObservableList<Product> getproductsAll() {
        return productsAll;
    }

    public ObservableList<Part> getPartsAll() {
        return PartsAll;
    }



}
