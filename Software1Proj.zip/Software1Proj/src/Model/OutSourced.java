
package Model;

public class OutSourced extends Part {

     String businessName;
    public void setbuisnessname(String name) {
        this.businessName = name;
    }
    public String getbuisnessName() {
        return businessName;
    }
    public OutSourced(int pID, String name, double price, int numberinstock, int minimum, int maximum, String business) {
        setstock(numberinstock);
        setmin(minimum);
        setmax(maximum);
        setbuisnessname(business);
        setid(pID);
        setname(name);
        setprice(price);

    }




}
