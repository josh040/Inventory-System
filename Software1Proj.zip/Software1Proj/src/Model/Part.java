package Model;
/**
 * Supplied class Part.java
 */

/**
 *
 * @author Joshua Novak
 */
public abstract class Part {
     int id;
     String name;
     double price;
     int stock;
     int minimum;
     int maximum;

    public Part() {
    }

    public Part(int id, String name, double price, int stock, int minimum, int maximum) {
        this.id = id;
        this.name = name;
        this.price = price;
        this.stock = stock;
        this.minimum = minimum;
        this.maximum = maximum;
    }

    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setid(int id) {
        this.id = id;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setname(String name) {
        this.name = name;
    }

    /**
     * @return the price
     */
    public double getPrice() {
        return price;
    }

    /**
     * @param price the price to set
     */
    public void setprice(double price) {
        this.price = price;
    }

    /**
     * @return the stock
     */
    public int getStock() {
        return stock;
    }

    /**
     * @param stock the stock to set
     */
    public void setstock(int stock) {
        this.stock = stock;
    }

    /**
     * @return the minimum
     */
    public int getMin() {
        return minimum;
    }

    /**
     * @param minimum the minimum to set
     */
    public void setmin(int minimum) {
        this.minimum = minimum;
    }

    /**
     * @return the maximum
     */
    public int getMax() {
        return maximum;
    }

    /**
     * @param maximum the maximum to set
     */
    public void setmax(int maximum) {
        this.maximum = maximum;
    }

}