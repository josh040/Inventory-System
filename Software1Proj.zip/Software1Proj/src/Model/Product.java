
package Model;

import java.util.ArrayList;

public class Product {
    int stockIn = 0;
    int minimum;
    int maximum;
     ArrayList<Part> assocParts = new ArrayList<Part>();
     int prodID;
     String name;
     double price = 0.0;


    public Product(int prodID, String name, double price, int stockIn, int minimum, int maximum) {
        instockSet(stockIn);
        minSet(minimum);
        maxSet(maximum);
        productidSet(prodID);
        nameSet(name);
        PriceSet(price);


    }
    public boolean removeAssociatedPart(int partToRemove) {
        int i;
        for (i = 0; i < assocParts.size(); i++) {
            if (assocParts.get(i).getId() == partToRemove) {
                assocParts.remove(i);
                return true;
            }
        }

        return false;
    }

    public Part lookupAssociatedPart(int partTofind) {
        for (int i = 0; i < assocParts.size(); i++) {
            if (assocParts.get(i).getId() == partTofind) {
                return assocParts.get(i);
            }
        }
        return null;
    }
    public void addAssociatedPart(Part partToAdd) {
        assocParts.add(partToAdd);
    }



    public int getPartsListSize() {
        return assocParts.size();
    }

    public int getProductID() {
        return prodID;
    }

    public void productidSet(int prodID) {
        this.prodID = prodID;
    }

    public String getName() {
        return name;
    }

    public void nameSet(String name) {
        this.name = name;
    }

    public double getPrice() {
        return price;
    }

    public void PriceSet(double price) {
        this.price = price;
    }

    public int getInStock() {
        return stockIn;
    }

    public void instockSet(int stockIn) {
        this.stockIn = stockIn;
    }

    public int getMin() {
        return minimum;
    }

    public void minSet(int minimum) {
        this.minimum = minimum;
    }

    public int getMax() {
        return maximum;
    }

    public void maxSet(int maximum) {
        this.maximum = maximum;
    }



}
